---
title: Curriculum Vitea
lang: en
ref: cv
---

[CV](CV_fufa_beyene.pdf)

